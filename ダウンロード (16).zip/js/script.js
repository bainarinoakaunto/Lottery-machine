// Write JavaScript herefunction login() {
    const input = document.getElementById("iroiro").value;
    const correct = "iroiro0012"; 

    if (input === correct) {
        window.location.href = "index.html";
    } else {
        document.getElementById("error").innerText = "パスワードが違います。";\
    }
}
